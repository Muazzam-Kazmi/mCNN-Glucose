# -*- coding: utf-8 -*-
"""
Created on Sat Apr 10 17:40:29 2021

@author: YZU
"""

import os
import joblib
from sklearn import svm
import pandas as pd
import numpy as np
import math
from sklearn import neighbors
from collections import Counter
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier


import math
from sklearn.metrics import confusion_matrix, auc
from sklearn.model_selection import ShuffleSplit
from collections import Counter
from sklearn.model_selection import StratifiedKFold

    
#def get_preds(threshold, probabilities):
#    return [1 if prob > threshold else 0 for prob in probabilities]

def evaluation(classifier, depth_max, num_estimators, features_max, label_list, pred_list, saveFileName):
   
    for threshold in np.linspace(0, 1, 100):
        
        pred_y = [1 if i > threshold else 0 for i in pred_list]
        
        TN, FP, FN, TP = confusion_matrix(label_list, pred_y, labels=[0, 1]).ravel()
   
        Sensitivity=round((TP/(TP+FN)), 4) if TP+FN >0 else 0
        Specificity=round(TN/(FP+TN), 4) if FP+TN >0 else 0
        Precision=round(TP/(TP+FP), 4) if TP+FP >0 else 0
        Accuracy = round((TP+TN)/(TP+FP+TN+FN), 4)
        MCC=round(((TP*TN)-(FP*FN))/(math.sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))), 4) if TP+FP >0 and FP+TN >0 and TP+FN and TN+FN else 0
        F1=round((2*TP)/((2*TP)+FP+FN), 4)
        
        TPR=round((TP/(TP+FN)), 4) if TP+FN >0 else 0
        FPR=round((FP/(FP+TN)), 4) if FP+TN >0 else 0
        
        print("Result:Threshold={0}, classifier= {5}\tTP={1}, FP={2}, FN={3}, TN={4}, Sens={6}, Spec={7}, Acc={8}, MCC={9}, TPR={10}, FPR={11}\n".format(round(threshold,2), TP, FP, FN, TN, classifier, Sensitivity, Specificity, Accuracy, MCC, TPR, FPR));
        
        f2=open(saveFileName,"a")
        results = str(round(threshold,2))+","+classifier+","+str(depth_max)+","+str(num_estimators)+","+str(features_max)+","+str(TP)+","+str(FP)+","+str(FN)+","+str(TN)+","+str(Sensitivity)+","+str(Specificity)+","+str(Accuracy)+","+str(MCC)+","+str(TPR)+","+str(FPR)
        f2.write("\n"+results)
        f2.close()

# Loading the dataset
WorkDir = "C:/PROJECT LAB/PAPERS/mCNN-Glucose/1 - Data/"
Main_Dir = WorkDir+"3 - Feature set/3 - Original PSSM/";
output_Dir = WorkDir+"5 - Results/ML Classifiers/Independent/1.Original_PSSM/2.RF/"

classes = ['class1', 'class2','class3']

for num_class in classes:
    
    my_train_data = 'pssm_'+num_class+'_train_smote';
    my_test_data = 'pssm_'+num_class+'_test';
    
    cv_file = Main_Dir+my_train_data+".csv"
    ind_file = Main_Dir+my_test_data+".csv"
        
    df_train = pd.read_csv(cv_file, header=None)
    train_x = df_train[df_train.columns[1:]]
    train_y = df_train[df_train.columns[0]]
    
    df_test = pd.read_csv(ind_file, header=None)
    test_x = df_test[df_test.columns[1:]]
    test_y = df_test[df_test.columns[0]]
    
    if num_class == 'class1':
       
        print("Current Class: {0}".format(str(num_class)));
        max_depth = 20
        max_features = 'auto'
        n_estimators =500
        classifier_name = 'Random Forest Classifier'
        
        print('max_depth: '+str(max_depth)+'\t n_estimators:'+str(n_estimators))
        model = RandomForestClassifier(max_depth= max_depth, n_estimators=n_estimators, max_features = max_features,  random_state=0)
        model.fit(train_x, train_y)
        pred = model.predict_proba(test_x)[:, 1]
        
        result_file = output_Dir+"Ind_rf_"+my_train_data+"_D_"+str(max_depth)+"_E_"+str(n_estimators)+"_F_"+str(max_features)+"_result.csv";
        # Output MATRIX
        print("Output Result: {0}".format(result_file));
        f2=open(result_file,"a")
        firstline = "Threshold,Classifier,max_depth,n_estimators,max_features,TP,FP,FN,TN,Sensitivity,Specificity,Accuracy,MCC,TPR,FPR"
        f2.write(firstline)
        f2.close()
        
        evaluation(classifier_name, max_depth, n_estimators, max_features, test_y, pred, result_file)
        
        max_depth = 20
        max_features = 'auto'
        n_estimators =500
        classifier_name = 'Random Forest Classifier'
        
        print('max_depth: '+str(max_depth)+'\t n_estimators:'+str(n_estimators))
        model = RandomForestClassifier(max_depth= max_depth, n_estimators=n_estimators, max_features = max_features,  random_state=0)
        model.fit(train_x, train_y)
        pred = model.predict_proba(test_x)[:, 1]
        
        result_file = output_Dir+"Ind_rf_"+my_train_data+"_D_"+str(max_depth)+"_E_"+str(n_estimators)+"_F_"+str(max_features)+"_result.csv";
        # Output MATRIX
        print("Output Result: {0}".format(result_file));
        f2=open(result_file,"a")
        firstline = "Threshold,Classifier,max_depth,n_estimators,max_features,TP,FP,FN,TN,Sensitivity,Specificity,Accuracy,MCC,TPR,FPR"
        f2.write(firstline)
        f2.close()
        
        evaluation(classifier_name, max_depth, n_estimators, max_features, test_y, pred, result_file)
    
    elif num_class == 'class2':
        
        print("Current Class: {0}".format(str(num_class)));
        max_depth = 20
        max_features = 'auto'
        n_estimators =1000
        classifier_name = 'Random Forest Classifier'
        
        print('max_depth: '+str(max_depth)+'\t n_estimators:'+str(n_estimators))
        model = RandomForestClassifier(max_depth= max_depth, n_estimators=n_estimators, max_features = max_features,  random_state=0)
        model.fit(train_x, train_y)
        pred = model.predict_proba(test_x)[:, 1]
        
        result_file = output_Dir+"Ind_rf_"+my_train_data+"_D_"+str(max_depth)+"_E_"+str(n_estimators)+"_F_"+str(max_features)+"_result.csv";
        # Output MATRIX
        print("Output Result: {0}".format(result_file));
        f2=open(result_file,"a")
        firstline = "Threshold,Classifier,max_depth,n_estimators,max_features,TP,FP,FN,TN,Sensitivity,Specificity,Accuracy,MCC,TPR,FPR"
        f2.write(firstline)
        f2.close()
        
        evaluation(classifier_name, max_depth, n_estimators, max_features, test_y, pred, result_file)
        
    elif num_class == 'class3':
        
        print("Current Class: {0}".format(str(num_class)));
        max_depth = 20
        max_features = 'auto'
        n_estimators =1000
        classifier_name = 'Random Forest Classifier'
        
        print('max_depth: '+str(max_depth)+'\t n_estimators:'+str(n_estimators))
        model = RandomForestClassifier(max_depth= max_depth, n_estimators=n_estimators, max_features = max_features,  random_state=0)
        model.fit(train_x, train_y)
        pred = model.predict_proba(test_x)[:, 1]
        
        result_file = output_Dir+"Ind_rf_"+my_train_data+"_D_"+str(max_depth)+"_E_"+str(n_estimators)+"_F_"+str(max_features)+"_result.csv";
        # Output MATRIX
        print("Output Result: {0}".format(result_file));
        f2=open(result_file,"a")
        firstline = "Threshold,Classifier,max_depth,n_estimators,max_features,TP,FP,FN,TN,Sensitivity,Specificity,Accuracy,MCC,TPR,FPR"
        f2.write(firstline)
        f2.close()
        
        evaluation(classifier_name, max_depth, n_estimators, max_features, test_y, pred, result_file)
    
        
    
    
    
