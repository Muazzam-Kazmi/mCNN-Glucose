# -*- coding: utf-8 -*-
"""
Created on Mon Sep  6 20:51:32 2021

@author: USER
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug  9 18:56:59 2021

@author: USER
"""
# =============================================================================
# Load Packages
# =============================================================================
import os
import joblib
from sklearn import svm
import pandas as pd
import numpy as np
import math
from collections import Counter
from sklearn.ensemble import ExtraTreesClassifier
import math
from sklearn.metrics import confusion_matrix, auc
from sklearn.model_selection import ShuffleSplit
from collections import Counter
from sklearn.model_selection import StratifiedKFold
set_Flag = False
##########################################################
# Confusion matrix
##########################################################
def evaluation(classifier, cost, gamma, svm_kernel, label_list, pred_list, saveFileName):
   
    for threshold in np.linspace(0, 1, 100):
        
        pred_y = [1 if i > threshold else 0 for i in pred_list]
        
        TN, FP, FN, TP = confusion_matrix(label_list, pred_y, labels=[0, 1]).ravel()
        
        Sensitivity=round((TP/(TP+FN)), 4) if TP+FN >0 else 0
        Specificity=round(TN/(FP+TN), 4) if FP+TN >0 else 0
        Precision=round(TP/(TP+FP), 4) if TP+FP >0 else 0
        Accuracy = round((TP+TN)/(TP+FP+TN+FN), 4)
        MCC=round(((TP*TN)-(FP*FN))/(math.sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))), 4) if TP+FP >0 and FP+TN >0 and TP+FN and TN+FN else 0
        F1=round((2*TP)/((2*TP)+FP+FN), 4)
        
        TPR=round((TP/(TP+FN)), 4) if TP+FN >0 else 0
        FPR=round((FP/(FP+TN)), 4) if FP+TN >0 else 0
        
        print("Result:Threshold={0}, classifier= {5}\tTP={1}, FP={2}, FN={3}, TN={4}, Sens={6}, Spec={7}, Acc={8}, MCC={9}, TPR={10}, FPR={11}\n".format(round(threshold,2), TP, FP, FN, TN, classifier, Sensitivity, Specificity, Accuracy, MCC, TPR, FPR));
        
        f2=open(saveFileName,"a")
        results = str(round(threshold,2))+","+classifier+","+str(cost)+","+str(gamma)+","+svm_kernel+","+str(TP)+","+str(FP)+","+str(FN)+","+str(TN)+","+str(Sensitivity)+","+str(Specificity)+","+str(Accuracy)+","+str(MCC)+","+str(TPR)+","+str(FPR)
        f2.write("\n"+results)
        f2.close()
    
WorkDir = "C:/PROJECT LAB/PAPERS/mCNN-Glucose/1 - Data/"
Main_Dir = WorkDir+"3 - Feature set/3 - Original PSSM/";
output_Dir = WorkDir+"5 - Results/ML Classifiers/Independent/1.Original_PSSM/3.SVM/"

classes = ['class1', 'class2','class3']
for num_class in classes:
    
    my_train_data = 'pssm_'+num_class+'_train_smote';
    my_test_data = 'pssm_'+num_class+'_test';
    
    cv_file = Main_Dir+my_train_data+".csv"
    ind_file = Main_Dir+my_test_data+".csv"
        
    df_train = pd.read_csv(cv_file, header=None)
    train_x = df_train[df_train.columns[1:]]
    train_y = df_train[df_train.columns[0]]
    
    df_test = pd.read_csv(ind_file, header=None)
    test_x = df_test[df_test.columns[1:]]
    test_y = df_test[df_test.columns[0]]
    
    if num_class == 'class1':
        print("Current Class: {0}".format(str(num_class)));
        
        c=10
        g='scale'
        kernel = 'rbf'
        classifier_name = 'SVM'
        
        model = svm.SVC(kernel = kernel, gamma=g, C=c, probability=True, random_state=0)
        model.fit(train_x, train_y)
        pred = model.predict_proba(test_x)[:, 1]
        result_file = output_Dir+"Ind_svm_"+my_train_data+"_C_"+str(c)+"_G_"+str(g)+'_k_'+str(kernel)+"_result.csv";
        print("Output Result: {0}".format(result_file));
        firstline = "threshold,classifier,cost,gamma,kernel,TP,FP,FN,TN,Sensitivity,Specificity,Accuracy,MCC,TPR,FPR"
        f2=open(result_file,"a") 
        f2.write(firstline)
        f2.close()
        evaluation(classifier_name, c, g, kernel, test_y, pred, result_file)
        
            
    elif num_class == 'class2':
        print("Current Class: {0}".format(str(num_class)));
        
        c=1
        g='scale'
        kernel = 'linear'
        classifier_name = 'SVM'
        
        model = svm.SVC(kernel = kernel, gamma=g, C=c, probability=True, random_state=0)
        model.fit(train_x, train_y)
        pred = model.predict_proba(test_x)[:, 1]
        result_file = output_Dir+"Ind_svm_"+my_train_data+"_C_"+str(c)+"_G_"+str(g)+'_k_'+str(kernel)+"_result.csv";
        print("Output Result: {0}".format(result_file));
        firstline = "threshold,classifier,cost,gamma,kernel,TP,FP,FN,TN,Sensitivity,Specificity,Accuracy,MCC,TPR,FPR"
        f2=open(result_file,"a") 
        f2.write(firstline)
        f2.close()
        evaluation(classifier_name, c, g, kernel, test_y, pred, result_file)
        
    elif num_class == 'class3':
        print("Current Class: {0}".format(str(num_class)));
        
        c=1
        g='scale'
        kernel = 'linear'
        classifier_name = 'SVM'
        
        model = svm.SVC(kernel = kernel, gamma=g, C=c, probability=True, random_state=0)
        model.fit(train_x, train_y)
        pred = model.predict_proba(test_x)[:, 1]
        result_file = output_Dir+"Ind_svm_"+my_train_data+"_C_"+str(c)+"_G_"+str(g)+'_k_'+str(kernel)+"_result.csv";
        print("Output Result: {0}".format(result_file));
        firstline = "threshold,classifier,cost,gamma,kernel,TP,FP,FN,TN,Sensitivity,Specificity,Accuracy,MCC,TPR,FPR"
        f2=open(result_file,"a") 
        f2.write(firstline)
        f2.close()
        evaluation(classifier_name, c, g, kernel, test_y, pred, result_file)
        